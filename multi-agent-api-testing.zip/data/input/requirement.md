# Sample API
GET /api/user
