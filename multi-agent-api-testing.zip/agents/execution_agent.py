import requests
from agents.base_agent import BaseAgent

class ExecutionAgent(BaseAgent):
    def __init__(self):
        super().__init__("ExecutionAgent")

    def run(self, data):
        return [{"status": "mocked"}]
