from agents.base_agent import BaseAgent

class EnvAgent(BaseAgent):
    def __init__(self):
        super().__init__("EnvAgent")

    def run(self, cases):
        return {"env": "ready", "testcases": cases}
