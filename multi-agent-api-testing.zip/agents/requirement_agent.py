from agents.base_agent import BaseAgent
from core.llm_client import call_llm

class RequirementAgent(BaseAgent):
    def __init__(self):
        super().__init__("RequirementAgent")

    def run(self, doc):
        return call_llm(f"Parse API requirements: {doc}")
