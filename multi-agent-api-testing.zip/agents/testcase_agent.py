from agents.base_agent import BaseAgent
from core.llm_client import call_llm

class TestCaseAgent(BaseAgent):
    def __init__(self):
        super().__init__("TestCaseAgent")

    def run(self, parsed):
        return call_llm(f"Generate test cases JSON: {parsed}")
