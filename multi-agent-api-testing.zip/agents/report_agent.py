from agents.base_agent import BaseAgent
from core.llm_client import call_llm

class ReportAgent(BaseAgent):
    def __init__(self):
        super().__init__("ReportAgent")

    def run(self, results):
        return call_llm(f"Analyze results: {results}")
