from core.workflow import TestWorkflow

if __name__ == "__main__":
    workflow = TestWorkflow()
    workflow.run("data/input/requirement.md")
