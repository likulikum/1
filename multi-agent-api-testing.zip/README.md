# Multi-Agent API Testing System

## Features
- Multi-agent API testing
- Auto requirement parsing
- Auto test case generation
- Auto execution and reporting

## Run
pip install -r requirements.txt
python main.py
