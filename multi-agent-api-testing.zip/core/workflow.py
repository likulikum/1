from agents.requirement_agent import RequirementAgent
from agents.testcase_agent import TestCaseAgent
from agents.env_agent import EnvAgent
from agents.execution_agent import ExecutionAgent
from agents.report_agent import ReportAgent

class TestWorkflow:
    def __init__(self):
        self.req = RequirementAgent()
        self.tc = TestCaseAgent()
        self.env = EnvAgent()
        self.exec = ExecutionAgent()
        self.report = ReportAgent()

    def run(self, path):
        with open(path, "r") as f:
            doc = f.read()

        parsed = self.req.run(doc)
        cases = self.tc.run(parsed)
        env = self.env.run(cases)
        results = self.exec.run(env)
        report = self.report.run(results)

        print(report)
